var config = {
    apiKey: "AIzaSyBB5FrvVkgwLiRw0-oBG0s2sd5SlffYeTI",
    authDomain: "usedtoys-e4d2b.firebaseapp.com",
    databaseURL: "https://usedtoys-e4d2b.firebaseio.com",
    projectId: "usedtoys-e4d2b"
 };
var firebase = firebase.initializeApp(config);